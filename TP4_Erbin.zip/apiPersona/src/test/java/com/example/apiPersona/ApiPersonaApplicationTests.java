package com.example.apiPersona;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiPersonaApplicationTests {

	@Test
	void contextLoads() {
	}

}
