package com.example.apiPersona;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiPersonaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiPersonaApplication.class, args);
	}

}
